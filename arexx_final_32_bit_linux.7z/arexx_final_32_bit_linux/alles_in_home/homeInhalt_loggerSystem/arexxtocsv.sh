#!/bin/bash
#grep '^\-\?[0-9]\{1,2\}\.[0-9]\{1\}$'
#https://www.systutorials.com/docs/linux/man/1-xxd/
# touch -m -d '2003-03-03' warn.txt

# den Tagesdateien neue Spalten hinzufügen:
# find -type f -exec sed -i 's/$/     ,/g' {} \;
# find -type f -exec sed -i 1c'\\' {} \;

# die Indexnummer entspricht der Spaltennummer in der CSV.
# spinnt wenn Shellskript in Console geht: typeset –ir sensnum 
# Wird zur Ermittlung der Spaltennummer in der CSV gebraucht.
# HH=`date +%H` # anhand des Unixtimestamp die Stunde das Tages 
# HH="${HH#"${HH%%[!0]*}"}" && : "${HH:=0}" #wegen-> führende 0 verursachte Oktal ....Basiszu groß.(Fehler ist\"08\"
# Aufruf_ stdbuf -oL ./rfcup/rfdeb9 -v | arexxtocsv.sh

#pidof ./rfcup/rf4 | wc -l 
#&& echo "Diese Anwendung ist bereits in einem anderen Fenster aktiv."; sleep 10; exit 0
#pgrep ./rfcup/rf4 && echo "Diese Anwendung ist bereits in einem anderen Fenster aktiv." && sleep 10 && exit 0


#if [[ `fuser lockfile` ]]; then
#	echo arexxProzessistbereitsaktiv
#	sleep 10
#	exit 1
#fi
#exec 4 >> lockfile

if ! mkdir /run/lock/arexxlockprozess 2>/dev/null; then
	echo -e "Arexxskript bereits aktiv. \n mit ALT und TAB Taste nach Fenster suchen. \n wenn nicht sichtbar alle Anwendungen schliessen und PC neu starten" >&2
	sleep 10
	exit 1
fi
trap -- "rmdir /run/lock/arexxlockprozess" EXIT

anzahlspalten=14

sensnum[0]=0
sensnum[1]=0
sensnum[2]=00134750
sensnum[3]=00011114
sensnum[4]=00008527
sensnum[5]=00066122
sensnum[6]=00009930
sensnum[7]=00134810
sensnum[8]=00004615
sensnum[9]=00011371
sensnum[10]=00008203
sensnum[11]=00008558
sensnum[12]=00008713
sensnum[13]=00008685
sensnum[14]=00132569
# spinnt wenn Shellskript in Console geht: typeset –r sensbez # Hier sind die Ueberschriften der CSV gespeichert. 
sensbez[0]="WirdNichtGebraucht"
sensbez[1]="Minute"
sensbez[2]="Mop-L<br>134750"
sensbez[3]="Mop-M<br>11114"
sensbez[4]="Mop-R<br>8527"
sensbez[5]="AHT<br>66122"
sensbez[6]="And<br>9930"
sensbez[7]="JBG-O<br>134810"
sensbez[8]="MeThek<br>4615"
sensbez[9]="KrObs<br>11371"
sensbez[10]="KrFle<br>8203"
sensbez[11]="Schok<br>8558"
sensbez[12]="Drink<br>8713"
sensbez[13]="Ausse<br>8685"
sensbez[14]="Natur<br>132569"

SensIDreinSpaltenNRraus() {
for i in "${!sensnum[@]}"; do  
    if [ ${sensnum[$i]} == $sensid ]; then 
        echo $i
        return 0
    fi
done
}

WarnungSchreiben() {
if (( $(( $(date +%s) - $(stat -c %Y ./public_html/warn.txt) )) >= 3600 )); then
    echo "${sensbez[$spalteNr]} : $tempvalue GradCelsius, Time:" `date` >> ./public_html/warn.txt
    (( `pidof xterm` )) || xterm -fullscreen -fa monaco -fs 24 -bg black -fg green -e "./beepwarnung.sh ; bash" & 
    return $?
fi
}

while read zeitusb sensid tempvalue; do 
	if [[ $zeitusb =~ ^[0-9]{10}$ ]] && [[ $sensid =~ ^[0-9]{8}$ ]] && [[ $tempvalue =~ ^-?[0-9]{1,2}.[0-9]{1}$ ]] && [[ `date -d @$zeitusb +%-j` = `date +%-j` ]]; then
		spalteNr=`SensIDreinSpaltenNRraus`
		if [[ $spalteNr = "" ]]; then
			echo -n "Unbekannt speichere in unknown.csv:"
			echo "`date -d @$zeitusb +%m%d%H%M`,$sensid,$tempvalue" | tee -a ./public_data/unknown.csv
			continue
		fi
		HH=`date -d @$zeitusb +%-H` # Stunde des gegebenen timestamps, das - vor H oder M bewirkt keine fuehrenden Nullen! -> Absicht weil sonst Oktalinterpretation
		MM=`date -d @$zeitusb +%-M` # was unten in der Zeile in der gerechnet wird zu falschen dezimalen Ergebnissen fuehren wuerde.
		WT=`date -d @$zeitusb +%u`
		case "$spalteNr" in
			2|3|4) (( ( ${tempvalue%%.*} < 1 || ${tempvalue%%.*} > 8 ) && $HH != 5 && $HH != 6 && $HH != 7 && $HH != 20 && $HH != 21 && $HH != 22 )) && WarnungSchreiben  ;;
			5) (( ${tempvalue%%.*} < -4 || ${tempvalue%%.*} > 9 )) && WarnungSchreiben  ;;
			6) (( ${tempvalue%%.*} < 0 || ${tempvalue%%.*} > 9 )) && WarnungSchreiben  ;;
			7) (( ( ${tempvalue%%.*} < 0 || ${tempvalue%%.*} > 9 ) \
			   && ( $WT != 7 ) && ( ! ( $WT == 6 && $HH > 18 ) ) && ( ! ( $WT == 1 && $HH < 8 ) ) \
			   )) && WarnungSchreiben  ;;
			8) (( ( ${tempvalue%%.*} < -1 || ${tempvalue%%.*} > 7 ) \
			   && ( $WT != 7 ) && ( ! ( $WT == 6 && $HH > 18 ) ) && ( ! ( $WT == 1 && $HH < 8 ) ) \
			   )) && WarnungSchreiben  ;;
			9|10) (( ${tempvalue%%.*} < 1 || ${tempvalue%%.*} > 9 )) && WarnungSchreiben  ;;
		esac

		YYYYmmdd=`date +%Y%m%d` # Dateiname je Tag eine Datei, Blankoinhalt wird mit Skript erzeugt.
		zahlddseek=$(($HH*60*$anzahlspalten+$MM*$anzahlspalten+$spalteNr-1)) # Hier wird der die Nummer des (bs=7) Byte-Blocks errechnet.
		echo -n $tempvalue | dd of=./public_data/${YYYYmmdd}.csv bs=6 count=1 conv=notrunc oflag=noatime status=none seek=$zahlddseek
		echo Werte $zeitusb $sensid $tempvalue
	else
		echo Unrelevant: $zeitusb $sensid $tempvalue
	fi
done