#!/bin/bash
echo -e "\n"
echo -e "\n"
echo -e "\n"
echo -e "\n"
echo -e "\n"
echo -e "\n"
echo -e "\n"
echo -e "\033[1;4;31m  WARNUNG: Temperatur Seite im Browser beachten!"
echo -e "  Mit Strg + C dieses Fenster und die Beep-Hinweis-Dauerschleife beenden. \033[0m"
echo "------------------------------------------------------------------------------------"
echo -e "\033[1;4;34;43m  WARNUNG: Temperatur Seite im Browser beachten!"
echo -e "  Mit Strg + C dieses Fenster und die Beep-Hinweis-Dauerschleife beenden. \033[0m"
while true; do 
	sleep 10
	beep -f 523.251 -l 100 -D 100 -n -f 391.995 -l 100 -D 100 -n -f 329.628 -l 100 -D 100 -n -f 261.626 -l 200 
done