#!/bin/bash
stdbuf -oL ./rfcup/rf4 -v | ./arexxtocsv.sh