#!/bin/bash
# Skript generiert die tagesdatei in der pro Minute eine Zeile mit MM:SS gefüllt wird und eine bestimmte
# Anzahl an ,      ,, um diese mit dd oder awk später mit Werten zu befüllen. Die Leerzeichen sind also nur Speicherslots um die Anzahl
# der benötigten HDD/SSD-Schreibzugriffe so gering wie nötig zu halten.
# ich unterdrücke als option von echo mit -n die Newlines am Ende aus folgendem Grund: Damit ich sie am Anfang in die Minuten-Zeitspannenspalte 
# packe um immer schön im 7 Byte Ryhtmus zu bleiben und mir damit viel Rechenaufwand spare um ein bestimmtes Datenfeld zu beschreiben
# ja ich weiß mit NULL die Slots frei zu halten wäre eleganter, das ändere ich ggf. noch später.	
#stunde=0
#minute=0
#ssmm=""
#while  (( $stunde <= 23 ))
#do     
#	while (( $minute <= 59 ))
#	do
#		  (( $minute < 10 )) && ssmm=0
#		  ssmm=$ssmm$minute
#		  if [ $stunde -lt 10 ]; then 
#			echo -ne "\n0$stunde$ssmm,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ," >> ./public_data/db.csv
#		  else
#		  	echo -ne "\n$stunde$ssmm,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ,     ," >> ./public_data/db.csv
#		  fi
#		  ((minute=minute+1))
#		  ssmm=""
#	done
#	((stunde=stunde+1))
#	minute=0
#done

# Im Terminal ausführen um Tage zu kopieren:
jahr=2022

for (( monat=1; monat<6; monat++ )); do
	for	(( tag=1; tag<32; tag++ )); do
		ctag=$tag
		cmonat=$monat
		(( $tag < 10 )) && ctag="0"$tag
		(( $monat < 10 )) && cmonat="0"$monat
		cp ./public_data/db.csv ./public_data/$jahr$cmonat${ctag}.csv
		sleep 1
	done
done