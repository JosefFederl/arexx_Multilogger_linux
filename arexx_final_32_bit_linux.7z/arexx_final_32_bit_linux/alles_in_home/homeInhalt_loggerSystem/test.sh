#!/bin/bash
tempvalue=8
(( ( ${tempvalue%%.*} < 0 || ${tempvalue%%.*} > 9 ) \
&& ( $WT != 7 ) \
&& ( $WT != 6 && $HH > 18 ) \
&& ( $WT != 1 && $HH < 8 ) \
)) && echo Warnungausgeben.
