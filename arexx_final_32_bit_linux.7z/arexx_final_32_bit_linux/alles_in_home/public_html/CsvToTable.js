/**
 * CSV to Table plugin
 *
 * Copyright (c) 2010 Steve Sobel
 * http://honestbleeps.com/
 *
 * 
 *
 */

 
 (function($){

	/**
	*
	* CSV Parser credit goes to Brian Huisman, from his blog entry entitled "CSV String to Array in JavaScript":
	* http://www.greywyvern.com/?post=258
	*
	*/
	String.prototype.splitCSV = function(sep) {
		for (var thisCSV = this.split(sep = sep || ","), x = thisCSV.length - 1, tl; x >= 0; x--) {
			if (thisCSV[x].replace(/"\s+$/, '"').charAt(thisCSV[x].length - 1) == '"') {
				if ((tl = thisCSV[x].replace(/^\s+"/, '"')).length > 1 && tl.charAt(0) == '"') {
					thisCSV[x] = thisCSV[x].replace(/^\s*"|"\s*$/g, '').replace(/""/g, '"');
				} else if (x) {
					thisCSV.splice(x - 1, 2, [thisCSV[x - 1], thisCSV[x]].join(sep));
				} else thisCSV = thisCSV.shift().split(sep).concat(thisCSV);
			} else thisCSV[x].replace(/""/g, '"');
		} return thisCSV;
	};

	$.fn.CSVToTable = function(csvFile, options) {
		var defaults = {
			tableClass: "CSVTable",
			theadClass: "",
			thClass: "",
			tbodyClass: "CSVtbody",
			trClass: "",
			tdClass: "tdc",
			loadingImage: "",
			loadingText: "Loading CSV data...",
			separator: ",",
			startLine: 0
		};	
		var options = $.extend(defaults, options);
		return this.each(function() {
			var obj = $(this);
			var error = '';
    var jetzt = new Date();
    HH = jetzt.getHours();
    MM = jetzt.getMinutes();
    HHS = HH +"";
    HHMMS = HHS + MM;  
			(options.loadingImage) ? loading = '<div style="text-align: center"><img alt="' + options.loadingText + '" src="' + options.loadingImage + '" /><br>' + options.loadingText + '</div>' : loading = options.loadingText;
			obj.html(loading);
                        
			$.get(csvFile, function(data) {
var tableHTML = '<table class="' + options.tableClass + '">';
				var lines = data.replace('\r','').split('\n');
				var printedLines = 0;
				var headerCount = 0;
				var headers = new Array();
				var tfootstring = '<tfoot id="idfoot" class="' + options.theadClass + '"><tr class="' + options.trClass + '">';
tableHTML += '<tr class="' + options.trClass + ' ' + oddOrEven + '">';            
tableHTML += '<td class="' + options.tdClass + '">Min  </td>';
tableHTML += '<td class="' + options.tdClass + '">MoprL</td>';
tableHTML += '<td class="' + options.tdClass + '">MoprM</td>';
tableHTML += '<td class="' + options.tdClass + '">MoprR</td>';
tableHTML += '<td class="' + options.tdClass + '">AHTMo</td>';
tableHTML += '<td class="' + options.tdClass + '">Andec</td>';
tableHTML += '<td class="' + options.tdClass + '">JBG-O</td>';
tableHTML += '<td class="' + options.tdClass + '">MezTh</td>';
tableHTML += '<td class="' + options.tdClass + '">Kr-Fl</td>';
tableHTML += '<td class="' + options.tdClass + '">Kr-Ob</td>';
tableHTML += '<td class="' + options.tdClass + '">Schok</td>';
tableHTML += '<td class="' + options.tdClass + '">Drink</td>';
tableHTML += '<td class="' + options.tdClass + '">Ausse</td>';
tableHTML += '<td class="' + options.tdClass + '">Natur</td>';
tableHTML += '<td class="' + options.tdClass + '"></td>';
tableHTML += '</tr>';

				$.each(lines, function(lineCount, line) {

						var items = line.splitCSV(options.separator);
						if (items.length > 1) {
							printedLines++;
							(printedLines % 2) ? oddOrEven = 'odd' : oddOrEven = 'even';
                                                        if ( printedLines == 59 ) {
							tableHTML += '<tr id="now" class="' + options.trClass + ' ' + oddOrEven + '">';
                                                        } else {
                                                        tableHTML += '<tr class="' + options.trClass + ' ' + oddOrEven + '">';            
                                                        }
                                                        
                                                    
                                                        $.each(items, function(itemCount, item) {
                                                           
                                                                tableHTML += '<td class="' + options.tdClass + '">' + item + '</td>';
                                                            
							});
							tableHTML += '</tr>';
				});
				
				tableHTML += '</tbody>';
				tfootstring += '</tr></tfoot>';
				tableHTML += tfootstring ;
				tableHTML += '</table>';
				
				if (error) {
					obj.html(error);
				} else {
					obj.fadeOut(500, function() {
						obj.html(tableHTML)
					}).fadeIn(function() {
						// trigger loadComplete
						setTimeout(function() {
							obj.trigger("loadComplete");	
						},0);
					});
				}
			});
		});
	};

})(jQuery);
