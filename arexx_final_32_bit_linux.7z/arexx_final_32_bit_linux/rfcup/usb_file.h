

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <libusb.h>
typedef unsigned char BYTE;
class CUSBDevice
{ 
	libusb_device_handle* m_hDevHandle;
	static unsigned char ENDPOINT_DOWN ;
	static unsigned char ENDPOINT_UP ;
public:
	CUSBDevice();
	~CUSBDevice();
	bool IsOpen() const;
	int Open();
	void Close();
	int Initialize_Device();
	int SendMsg(BYTE* send, BYTE* ret);
};
