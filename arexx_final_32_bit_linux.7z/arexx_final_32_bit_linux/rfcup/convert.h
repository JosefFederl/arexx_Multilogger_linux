
#ifndef _CONVERT_H_
#define _CONVERT_H_

extern char scratchbuf[32];
 

char* strcarlong(char* buf, long val);
 
char* strcarhex(char* buf, char val);  
char* getRoundedFloat(float f, int prec, char* buf); 
char* getRoundedFloatEnc(float f, int prec, char* buf, bool  bEncode);

#endif
