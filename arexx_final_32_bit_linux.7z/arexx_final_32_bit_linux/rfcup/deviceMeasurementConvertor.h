#pragma once

#include <string>
#include <vector>
using namespace std;
#include "xmlParser.h"


struct convert
{
	float value;
	int externaltype;
	int externaldeviceid;
};

class CDeviceMeasurementConvertor
{
	int m_Scale;
	unsigned long m_TypeMask1;
	unsigned long m_TypeMask2; 
	int m_Type;
	unsigned long m_Devicemask; 
	vector<float> m_Poly;
	float m_vLower, m_vUpper;
	int m_SignedWord;
public:
	CDeviceMeasurementConvertor(void);
	CDeviceMeasurementConvertor(const CDeviceMeasurementConvertor& c);
	~CDeviceMeasurementConvertor(void);
	void operator =(const CDeviceMeasurementConvertor& c);
	bool LoadFromXML(XMLNode &node);
	bool Convert(unsigned long device, unsigned short nt, convert & c);
	bool GetExternalDeviceID(long idUniqueDevice, long &idExternalDevice, long &type);
	bool GetUniqueDeviceID(unsigned long idExternalDevice, unsigned long type, long& idUniqueDevice);
	
};
