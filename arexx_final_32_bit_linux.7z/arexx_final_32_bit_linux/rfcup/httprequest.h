

struct context
{
	int type;
	int device;
	int time;
	float value;
	float rssi;
	void Format(char*s, const char* f);
};
int httpRequest(const char* surl, const char* sMsg, context &c, bool bPost);


void GetOwnIP();
