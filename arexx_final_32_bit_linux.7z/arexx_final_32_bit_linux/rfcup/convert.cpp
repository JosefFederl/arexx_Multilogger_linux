 
#include <stdio.h>
#include <stdlib.h>
#include "convert.h"
#include "str.h"
 
long tzone;
char scratchbuf[32];
 
char* strcarlong(char* buf, long val)
{
	sprintf(scratchbuf, "%ld", val);
	return strcat1(buf, scratchbuf);

}
char* strcarhex(char* buf, char val)
{
	sprintf(scratchbuf, "%x", val);
	return strcat1(buf, scratchbuf);

}
   

char* getRoundedFloat(float f, int prec, char* buf)
{ 
	int fcvtbuf_d, fcvtbuf_s;
	char* b = fcvt(f, prec, &fcvtbuf_d, &fcvtbuf_s ) ; 
	if (fcvtbuf_s)
		*buf++ = '-';
	if (fcvtbuf_d==0)
		*buf++ = '0';
	else
	{
		for (int i=0;i<fcvtbuf_d;i++)//integer part
			*buf++ = *b++;
	}
	if (*b!=0)
	{
		*buf++ = '.';
		return strcat1(buf, b); 
	}
	else
		return  buf;
}

char* getRoundedFloatEnc(float f, int prec, char* buf, bool  bEncode)
{ 
	if (!bEncode)
		return getRoundedFloat(f, prec, buf);
	int fcvtbuf_d, fcvtbuf_s;
	char* b = fcvt(f, prec, &fcvtbuf_d, &fcvtbuf_s ) ; 
	if (fcvtbuf_s)
		buf = strcat1(buf, "%2D"); //*buf++ = '-';
	if (fcvtbuf_d==0)
		*buf++ = '0';
	else
	{
		for (int i=0;i<fcvtbuf_d;i++)//integer part
			*buf++ = *b++;
	}
	if (*b!=0)
	{ 
		buf = strcat1(buf, "%2E"); // *buf++ = '.';
		return strcat1(buf, b); 
	}
	else
		return  buf;
}

