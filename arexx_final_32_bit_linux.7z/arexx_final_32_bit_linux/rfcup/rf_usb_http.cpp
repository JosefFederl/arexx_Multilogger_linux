// rf_usb_http.cpp : Defines the entry point for the console application.
//
#define _VERSION_ "0.6"

#include <stdio.h>
#include <string.h>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;


#include <time.h>
#include <time.h>
#include "usb_file.h" 
#include "defaultConverters.h"
#include "deviceMeasurementConvertor.h"
#include "httprequest.h"
bool bVerbose;
bool bOldRecords;


#define MAKEWORD(a, b) ((unsigned short)(a) | (unsigned short)((b)<<8))

#define CC1000_WRITE_CONFIG			0x01
#define CC1000_READ_CONFIG			0x02
#define CC1000_READ_RFDATA			0x03
#define USB_SET_TICKCOUNT			0x04 
#define USB_WRITE_EEPROM			0x05
#define USB_READ_EEPROM				0x06

#define tl_RSSI_Included 0x8000
 
#define SET_USB_TIME_PERIOD_SEC (6*60*60) // 6 hours

#define SYNC_CONNECT_PERIOD 60*1000 // msec
#define USB_POLLING_PERIOD 1500 // msec
#define SET_USB_TIME_PERIOD	(SET_USB_TIME_PERIOD_SEC*1000/USB_POLLING_PERIOD) // 6 hours in timer events
#define MAX_USB_TIME_RESPONSE (SET_USB_TIME_PERIOD_SEC+30*60) // add some margin

  

int usage()
{
//	printf("rf_usb_http version %s\n", _VERSION_);
	printf("reads data from a rf_usb device and displays it in the Terminal use -v\n");
//	printf("usage:\n");
//	printf("rf_usb_http [options] rule_file\n");
	printf("options:\n");
	printf("-v:	verbose\n");
	printf("-h:	process old data from flash memory as well\n");
//	printf("rule_file:	messages are sent according to this rule file\n");
//	printf("rule_file:	only url-encoded get and post requests are supported at this moment\n");
	return 1;
}

#define LINE_TYPE 0
#define LINE_CONDITION 1
#define LINE_URL 2
#define LINE_MSG 3
char lines[4][256];

time_t basetime = 0;

vector<CDeviceMeasurementConvertor> deviceMeasurementConvertors;

CUSBDevice usbDevice;
long usbCountdown;
int SetUSBClock();

int processData(BYTE* pBuf);
 
 

int SetUSBClock(void)
{ 
	int r(0);
	if ( !usbDevice.IsOpen())  
		return -1;
	if (bVerbose)
		printf("SetUSBClock\n");
	BYTE sendBuf[64];
	BYTE retBuf[64]; 
	sendBuf[1] = 0;

	time_t ltime;
	time(&ltime);
	ltime -= basetime; 
	unsigned long t = (unsigned long)ltime;
	sendBuf[0] = USB_SET_TICKCOUNT;
	memcpy(sendBuf+1, &t, 4);
	if (bVerbose)
		printf("set clock to %lu\r\n", t);
	r = usbDevice.SendMsg(sendBuf, retBuf);  
	if (r!=0  )
	{    
		usbDevice.Close();
		return r;
	}
	
	// flush data
	sendBuf[0] = CC1000_READ_RFDATA;
	r = usbDevice.SendMsg(sendBuf, retBuf); 
		
	if (r!=0 )
	{  
		usbDevice.Close();
		return r;
	}

	usbCountdown = SET_USB_TIME_PERIOD ;    
	return 0;
}

int load_rulefile(char* strFile)
{
	memset(lines, 0, sizeof(lines)); 
	ifstream is(strFile); 
	if (!is) 
	{
		printf("cannot open rulefile %s\n", strFile);
		return 1;
	}
	if (bVerbose)
		printf("read rulefile %s\n", strFile);
	char line[256];
	while (!is.eof())
	{
		line[0]=0;
		is.getline(line, sizeof(line)-1);
		switch(line[0])
		{
		case 'B':
			strcpy(lines[LINE_TYPE], line+1);
			break;
		case 'D':
			strcpy(lines[LINE_CONDITION], line+1);
			break;
		case 'E':
			strcpy(lines[LINE_URL], line+1);
			break;
		case 'Z':
			strcpy(lines[LINE_MSG], line+1);
			is.close(); 
			return 0; 
		}
	} 
	is.close(); 
	return 1; 
}

bool LoadConvertInfoXML(const char* strFile)
{ 
	if (bVerbose)
		printf("loading %s\n", strFile);
	XMLResults xmlErr;
	xmlErr.error = eXMLErrorEmpty;
	XMLNode rootDocNode ;
	if (strlen (strFile)!=0) 
	{   
		rootDocNode = XMLNode::parseFile( strFile , "deviceinfo", &xmlErr);
	}
	if (xmlErr.error !=  eXMLErrorNone) 
	{     
		printf("error %d\n", xmlErr.error);
		rootDocNode = XMLNode::parseString( strDefaultConverters , "deviceinfo", &xmlErr);
	}  
	
	XMLNode v = rootDocNode.getChildNode("version");    
	if (bVerbose)
		printf("version = %s\n", v.getText());
	XMLNode  types = rootDocNode.getChildNode("devicetypes");
	int n = types.nChildNode("devicetype" ) ;
	

	deviceMeasurementConvertors.clear();
  
	int iter = 0;
    	for (int i=0 ; i<n; i++)
	{ 
		CDeviceMeasurementConvertor c; 
		XMLNode a = types.getChildNode("devicetype" ,&iter); 
		if ( c.LoadFromXML( a ))
			deviceMeasurementConvertors.push_back(c);
	}
	if (deviceMeasurementConvertors.size()==0)
	{
		if (strlen (strFile)!=0) // only recurse once
			return LoadConvertInfoXML("");
		else
		{
			
			if (bVerbose)
				printf("failed\n") ;  
			return false;
		}
	}
	else
	{ 
		if (bVerbose)
			printf("success (%d types)\n", deviceMeasurementConvertors.size())  ;  
		return true;
	}
}

void init()
{
	usbCountdown = SET_USB_TIME_PERIOD ; 
	tm t2000;
	memset(&t2000, 0, sizeof(t2000));
	t2000.tm_year = 2000-1900;
	t2000.tm_mday = 1;
	t2000.tm_mon = 0;
	basetime = timegm(&t2000);  
 
	if (bVerbose)
		printf("basetime = %ld\n", basetime);
	usbDevice.Open();
	SetUSBClock();
	LoadConvertInfoXML("./device.xml"); 
	
	GetOwnIP();
}


int usb_loop()
{ 
	int r(0);
	if (!usbDevice.IsOpen())
	{
		r = usbDevice.Open(); 
		if ( r )
			return  r;

		SetUSBClock();
	} 
	BYTE sendBuf[64]; 
	BYTE retBuf[64]; 
	int nFound(0);
	int nRead(0); 
	do
	{   
		nFound = 0;
		memset(retBuf, 0, sizeof(retBuf));
		memset(sendBuf,  0, sizeof(sendBuf));
		nFound = 0;
		sendBuf[0] = CC1000_READ_RFDATA;
		sendBuf[1] = 0;
		r = usbDevice.SendMsg(sendBuf, retBuf);  
		if ( r != 0  )
		{   
			usbDevice.Close(); 
			return r; 
		}
		if (retBuf[0]==0 && retBuf[1]>0) //status ok + data present 
		{ 
			nFound++;
			int i = retBuf[1]+1;
			if (i>8 && i<64)
				nFound++; 

			processData(retBuf );
		}
	}
	while(nFound>1);// continue read if data found
	
	if (usbCountdown <=0) 
	{
		return SetUSBClock(); 
	}  
	return (nFound==0)?1:0;// say it's an error if no data came in
}


int processData(BYTE* retBuf)
{
	if (retBuf[0] != 0)
		return 0;

	int i = 1;
	while (i<64)
	{  
		int szPayload = retBuf[i]; 
		if (szPayload <8 || szPayload>12)
			break;
		int base = i+1; 
		
		unsigned long uniquedevice = MAKEWORD(retBuf[base+0], retBuf[base+1]);   

		if (szPayload > 10)
		{
			base += 2;
			uniquedevice |= (MAKEWORD(retBuf[base+0], retBuf[base+1]) << 16); 
		} 

		float rssi = 0;  
		bool bValueValid = false;
		convert conv ;
		unsigned short nt = MAKEWORD(retBuf[base+3], retBuf[base+2]);
		for (size_t c=0;c<deviceMeasurementConvertors.size(); c++)
		{
			if (bValueValid = deviceMeasurementConvertors[c].Convert(uniquedevice, nt, conv))
				break;
		} 
		if (bValueValid)
		{ 
			if (szPayload==10 || szPayload==12)
			{ 
				const float vrssi = 3.3f*((float)retBuf[base+8])/256.0f;
				rssi = -51.3f*vrssi - 49.2f; //chipcon cc1000
				conv.externaltype |=  tl_RSSI_Included;
			}

			unsigned long t =0;
			memcpy(&t,  retBuf+base+4, 4); 

			time_t tMeasure = t + basetime;

			time_t tNow;
			time(&tNow);
			if (tMeasure > tNow + 60)
			{ 
				if (bVerbose)
		  //	printf("%d: Predicting!: time = %d, before last ( %d now,  d= %d sec)\n", i, (int)tMeasure,  (int)tNow ,(int)( tMeasure - tNow ));
				usbCountdown--;
				break; 
			}
			if (tMeasure > tNow + 5)
			{

				if (bVerbose)
		//		printf("%d: Predicting!: time = %d, before last ( %d now,  d= %d sec)\n", i, (int)tMeasure,  (int)tNow ,(int)( tMeasure - tNow ));
				usbCountdown--; 
			} 
			bool bRecent = (tMeasure > tNow - 60) ; // only synchronize a recent measurement
					   


				int ttt = tMeasure; 
				

					printf("%u %08u %.1f\n", ttt, conv.externaldeviceid, conv.value); 


				 
			i+= szPayload;
		} 
		else
		{
			
			if (bVerbose)
				printf("measurement not valid or unknown type\n");
			i+= szPayload;
		}
	}  
	return 0;

}
   #include <sys/ioctl.h>

int kbhit()
{
	int i(0);
	ioctl(0, FIONREAD, &i);
	return i; /* return a count of chars available to read */
}


int  main(int argc, char* argv[])
{
	bVerbose = false;
	bOldRecords = false;
	if (argc < 2)
		return usage();
	printf("hit enter to stop\n"); 
	for (int iFile= 1; iFile<argc; iFile++)
	{
		if (strcmp(argv[iFile],  "-v")==0)
		{  
			bVerbose=true;
			printf("verbose output\n");
		}
		else if (strcmp(argv[iFile],  "-h")==0)
		{ 
			bOldRecords=true;
			printf("process old records\n");
		}
	}
	//if (load_rulefile(argv[argc-1]))
	//	return 1;
	init();
	   
	for (;;)
	{ 
		usb_loop();  
		if (kbhit()>0 && getchar() == '\n')
			break;

  
		sleep(2); 
	} 
	usbDevice.Close();
	return 0;
}

