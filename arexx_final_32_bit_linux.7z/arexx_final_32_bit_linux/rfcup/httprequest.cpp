#include <stdio.h>
#if defined(WIN32) 
#include <Winsock2.h>
#else
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>
 #include <netdb.h> 

#include <sys/types.h> 
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>

#define closesocket close
#define SOCKET_ERROR (-1)
#endif

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "str.h"
#include "convert.h"
#include "httprequest.h"

#define BUFFSIZE 32 
char ownip[32];

void GetOwnIP()
{
	int fd;
	struct ifreq ifr;

	fd = socket(AF_INET, SOCK_DGRAM, 0);

	/* I want to get an IPv4 IP address */
	ifr.ifr_addr.sa_family = AF_INET;

	/* I want IP address attached to "eth0" */
	strncpy(ifr.ifr_name, "eth0", IFNAMSIZ-1);

	ioctl(fd, SIOCGIFADDR, &ifr);

	close(fd);

	strcpy(ownip,  inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr) );
	if ( ((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr.s_addr == 0)
		strcpy(ownip, "127.0.0.1");
	/* display result */
	printf("ip address = %s\n",ownip);
}

extern bool bVerbose; 

char* strcatReplaceTags1(char* pBuf, const char* src, context &ctxt, bool bEncode )
{
	char c; 
	char* z = (char*)src;
	if (z == NULL)
		return pBuf; 
	while((c = *z++) !=0 )
	{
		if (c != '$')
		{ 
			if (c == '\r') {  c = *z++; if (c==0) goto end_scan;};
			if (c == '\n')
			{   
				goto end_scan;
			 
			}
			else if (bEncode && c == '=')  
			{ 
				if (*z == '=')
				{ *pBuf++ = '='; *pBuf = 0; z++; }
				else
					pBuf = strcat1(pBuf, "%3D"); 

			}
			else if (bEncode && c == '&')  
			{
				if (*z == '&')
				{ *pBuf++ = '&'; *pBuf = 0; z++;}
				else
					pBuf = strcat1(pBuf, "%26"); 
			}
			else if  (bEncode && ! isalnum (c) )
			{
				*pBuf++ = '%'; *pBuf = 0;
				pBuf = strcarhex(pBuf, c);
			}
			else
			{
				*pBuf++ = c; *pBuf = 0;
			}   
		}
		else
		{ 
			c = *z++;
			switch( c )
			{
			case 0:
				*pBuf = 0;   
				return pBuf;  
			case '\n':  
			case '\r':  
				return pBuf;  
			case '$':
				*pBuf++ = '$';
				break;
			case 'v':  
				pBuf = getRoundedFloatEnc(ctxt.value, 1, pBuf , bEncode )  ; 
				break; 
			case 'i': 
				pBuf = strcarlong(pBuf, ctxt.device );
				break;  
			case 'q': 
				pBuf = strcarlong(pBuf, ctxt.type&0xff );
				break;   
			case 'r': 
				pBuf = strcarlong(pBuf,ctxt.rssi);  
				break;  
			case 'S':    
			case 'w':
				pBuf = strcarlong(pBuf, ctxt.time);  
				break;    
				
			}

		} 
	}  
end_scan: 
	*pBuf = 0;
	return pBuf;
}


int Request(const char* url, int port, const char* msg)
{
	if (bVerbose)
		printf("request to %s, %d\n%s\n", url, port, msg);
 
	int sock;
    char buffer[BUFFSIZE];
    unsigned int echolen;
    int received = 0;
 

    /* Create the TCP socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) 
	{
		if (bVerbose)
			printf("no socket\n");
		return 1;
    }
/* Construct the server sockaddr_in structure */ 

    sockaddr_in httpserver;
    memset(&httpserver, 0, sizeof(httpserver));       /* Clear struct */
    httpserver.sin_family = AF_INET;                  /* Internet/IP */

	hostent* host = gethostbyname(url); 
	if (host == NULL)
		httpserver.sin_addr.s_addr = inet_addr(url);
	else
    	httpserver.sin_addr.s_addr = *((unsigned long *) host->h_addr_list[0])  ;  /* IP address */
    httpserver.sin_port = htons(port) ;       /* server port */
    /* Establish connection */
    if (connect(sock, (sockaddr *) &httpserver, sizeof(httpserver)) < 0) 
	{
		if (bVerbose)
			printf("no connect\n");
		closesocket(sock);
		return 2;
    }

/* Send the word to the server */
    int lenMsg = strlen(msg);
    if (send(sock, msg, lenMsg, 0) != lenMsg) 
	{
		if (bVerbose)
			printf("no send\n");
		closesocket(sock);
		return 3;
    } 
    /* Receive the word back from the server */
	received = 0;
	while (received < 100)
	{
		int bytes = 0;
		bytes = recv(sock, buffer, BUFFSIZE-1, 0);
		if (bytes == 0) 
			break; 
		if (bytes == SOCKET_ERROR)
		{
			closesocket(sock);
			if (bVerbose)
				printf("no receive\n");
			return 4;
		}
		received += bytes;
		buffer[bytes] = '\0'; 
		if (bVerbose)      
      		printf("%s", buffer);
	} 
	
	closesocket(sock);
	return 0;
}



// copy string to scratch buffer and decode portnumber
void DecodeURL(char* z, char* ip, char* page, int& port)
{
	int i;
	port = 80;
	*page = 0;
	*ip = 0;
	while (*z == ' ') z++;
	if (strncmp(z, "http://", 7) == 0)
		z += 7;
	// copy root part
	for (i=0;i<255;i++)
	{
		if ( *z == 0 || *z == ':' || *z =='/' ) break; 

		if (*z > ' ') 
		  *ip++ = *z; 
		z++;
	}
	*ip = 0; 
	
	if (*z == ':')
	{
		z++; 
		// read port number
		char* zz;
		port = strtol(z,  &zz, 10);  
		if (z == zz)
			port = 80; 
		z = zz;
	}
	if (*z == '/')
	{ 
		// copy file part 
		for (i=0;i<255;i++)
		{
			if ( *z == 0  ) break; 
			if (*z > ' ') 
				*page++ = *z;
			z++;
		}  
	}
	*page = 0; 
	 
}

int httpRequest(const char* surl, const char* sMsg, context &c, bool bPost) 
{ 
	char msg[1024];
	char request[2048];
	char url[256];
	char host[256] ;
	char page[256] ;
	msg[0]=0;
	page[0]=0;
	strcatReplaceTags1(msg, sMsg, c, true);
	 
	strcpy(url, surl);

	int port=80;
	DecodeURL(url, host, page, port); 
	if (strlen(page)==0)
		strcpy(page, "/"); 
	
	if (bPost)
	{  
		sprintf(request, "POST %s HTTP/1.1\r\n"
							"Host:%s\r\n"
							 "Content-Type: application/x-www-form-urlencoded\r\n"
							 "Connection: close\r\n"
							 "Content-Length: %d\r\n"
							"\r\n%s\r\n", 
							page, 
							host,
							strlen(msg),
							msg );
	}
	else
	{  
		sprintf(request, "GET %s?%s HTTP/1.1\r\nHost:%s\r\n\r\n\r\n", page,  msg, host);
	}
	return Request(host, port, request); 
}


