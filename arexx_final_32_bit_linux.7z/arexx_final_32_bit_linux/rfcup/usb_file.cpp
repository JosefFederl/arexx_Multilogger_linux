 
#include <malloc.h>
#include "usb_file.h"
extern bool bVerbose;

uint16_t VENDOR = 1105; /* 0451 */
uint16_t PRODUCT = 12817; /* 3211 */
unsigned char CUSBDevice::ENDPOINT_DOWN = 0x2;
unsigned char CUSBDevice::ENDPOINT_UP = 0x82;

libusb_device_handle* find_rf_usb(libusb_device **devs) 
{
    libusb_device *dev(NULL);
    libusb_device_handle *handle(NULL);
    int i = 0; 
    while ((dev = devs[i++]) != NULL) 
	{
        struct libusb_device_descriptor desc;
        int r = libusb_get_device_descriptor(dev, &desc);
        if (r < 0) 
		{
			if (bVerbose)
            	fprintf(stderr, "failed to get device descriptor");
            return NULL;
        }
 

        if (desc.idVendor == VENDOR && desc.idProduct == PRODUCT) 
		{
			handle = NULL;
            printf("Found rf_usb (bus %d, device %d).\n", libusb_get_bus_number(dev), libusb_get_device_address(dev));
            int err = libusb_open(dev, &handle);
			if (err)
				printf("Error in opering rf_usb (%d)\n", err);

            return handle;
        }
    }

    return NULL;
};



///////////////////
//CUSBDevice

CUSBDevice::CUSBDevice()
:m_hDevHandle(NULL) 
{
	libusb_init(NULL);
}

CUSBDevice::~CUSBDevice()
{
	Close(); 
	    libusb_exit(NULL);
}


int CUSBDevice::Initialize_Device()
{
    int r =0;
	m_hDevHandle =  libusb_open_device_with_vid_pid (NULL, VENDOR, PRODUCT);

    if (m_hDevHandle == NULL) 
	{
        fprintf(stderr, "No rf_usb found.\n");  
        return -1;
    }       
	else if (bVerbose)
		printf("\nlibusb_open_device_with_vid_pid ok\n");   
	  
	r = libusb_claim_interface(m_hDevHandle, 0);  
	if (r !=0 && bVerbose)
		printf("\nClaim Interface %d (%s)\n", r, libusb_error_name(r));     
	return r;
}


int  CUSBDevice::Open ( )
{
	if (IsOpen())
		return 0; 
	int r= Initialize_Device();
	if (r != 0)
	{
		Close();
		return r;
	}
	return 0;
}



void CUSBDevice::Close ( )
{
	if (bVerbose)
		printf("close usb\n");

	if (m_hDevHandle)
	{
		libusb_release_interface(m_hDevHandle, 0);    
		m_hDevHandle = NULL;
	} 

}
bool CUSBDevice::IsOpen() const
{
	return (m_hDevHandle != NULL);
}

int CUSBDevice::SendMsg(BYTE* send, BYTE* ret)
{
	if (m_hDevHandle == NULL)
		return -1;
	int bResult(0);

	int bytesWritten(0), bytesRead(0);

	int r; 

	 r = libusb_bulk_transfer(m_hDevHandle, ENDPOINT_DOWN, send, 64, &bytesWritten, 200);
	if (r == 0)
    {
		r = libusb_bulk_transfer(m_hDevHandle, ENDPOINT_UP, ret,  64, &bytesRead, 200);
		if (r)
			printf("SendMsg error r %d (%s), transferred = %d\n", r, libusb_error_name(r), bytesRead);
	}
	else 
	{ 
		printf("SendMsg error w %d (%s), transferred = %d\n", r, libusb_error_name(r), bytesWritten);  
	}
	if (r==-7) // timeout
		r=0;
	//if (r)
	//	printf("SendMsg error %d\n", r);
	return r;
}

