# bouwen
# sudo ./ttt.sh
g++ -c -g -I /home/arexx/rfcup/lib_usb_1.0/ rf_usb_http.cpp -orf_usb_http.o
g++ -c -g defaultConverters.cpp -odefaultConverters.o
g++ -c -g deviceMeasurementConvertor.cpp -odeviceMeasurementConvertor.o
g++ -c -g -I /home/arexx/rfcup/lib_usb_1.0/ usb_file.cpp -ousb_file.o
g++ -c -g xmlParser.cpp -oxmlParser.o
g++ -c -g httprequest.cpp -ohttprequest.o
g++ -c -g str.cpp -ostr.o
g++ -c -g convert.cpp -oconvert.o
g++ -g -o rf4 rf_usb_http.o deviceMeasurementConvertor.o defaultConverters.o xmlParser.o usb_file.o httprequest.o str.o convert.o -lusb-1.0 -lpthread
