
#include <stdio.h>
#include "deviceMeasurementConvertor.h"
#include <math.h>

CDeviceMeasurementConvertor::CDeviceMeasurementConvertor(void):
m_TypeMask1(0xffff), m_TypeMask2(0), 
m_vLower(0), m_vUpper(0), m_Type(0), m_Devicemask(0xffff), m_Scale(0), m_SignedWord(0)
{
}

CDeviceMeasurementConvertor::CDeviceMeasurementConvertor(const CDeviceMeasurementConvertor& c):
m_TypeMask1(c.m_TypeMask1), m_TypeMask2(c.m_TypeMask2), 
m_vLower(c.m_vLower), m_vUpper(c.m_vUpper),
m_Poly(c.m_Poly), m_Type(c.m_Type), m_Devicemask(c.m_Devicemask), m_Scale(c.m_Scale), m_SignedWord(c.m_SignedWord)
{
}

void CDeviceMeasurementConvertor::operator =(const CDeviceMeasurementConvertor& c)
{
	m_TypeMask1=c.m_TypeMask1;
	m_TypeMask2=c.m_TypeMask2; 
	m_vLower=c.m_vLower; 
	m_vUpper=c.m_vUpper;
	m_Poly=c.m_Poly;
	m_Type = c.m_Type;
	m_Devicemask = c.m_Devicemask;
	m_Scale = c.m_Scale;
	m_SignedWord = c.m_SignedWord;
}

CDeviceMeasurementConvertor::~CDeviceMeasurementConvertor(void)
{
}
 
bool CDeviceMeasurementConvertor::LoadFromXML(XMLNode &node)
{    
	const char* c;
	if  (c=node.getChildNode("m1" ).getText()) 
	{
		char *cc;
		string s("0x");
		s +=c;
		m_TypeMask1 = strtoul(s.c_str(), &cc, 16); 
	} 
	if  (c=node.getChildNode("m2" ).getText()) 
	{
		string s("0x"); char *cc;
		s +=c;
		m_TypeMask2 = strtoul(s.c_str(), &cc, 16); 
	} 
	if  (c=node.getChildNode("type" ).getText()) 
	{
		char *cc; 
		m_Type = strtol(c, &cc, 10);
	} 
	if  (c=node.getChildNode("dm" ).getText()) 
	{
		string s("0x"); char *cc;
		s +=c;
		m_Devicemask = strtoul(s.c_str(), &cc, 16);
	}  
	if  (c=node.getChildNode("scale" ).getText()) 
	{
		string s(c); char *cc; 
		m_Scale = strtol(s.c_str(), &cc, 10);
	} 
	if  (c=node.getChildNode("vLo" ).getText()) 
		m_vLower = atof(c) ; 
	if  (c=node.getChildNode("vUp" ).getText()) 
		m_vUpper = atof(c) ; 
	m_SignedWord =0;
	if  (c=node.getChildNode("i" ).getText()) 
		m_SignedWord = atof(c) ; 
	m_Poly.clear();
	int n = node.nChildNode("p" ) ;
	if (n>8)
		n=8;
    for (int i=0, iter=0; i<n; i++)
	{
		float f(0);
		if  (c=node.getChildNode("p" ,&iter).getText())    
			f = atof(   c ) ; 
		m_Poly.push_back(f);
	}  
	return true;
}

bool CDeviceMeasurementConvertor::Convert(unsigned long device, unsigned short wnt, convert & c)
{
	if (m_Poly.size()==0)
		return false;
	if ((m_TypeMask1 & device) != m_TypeMask2)
		return false;
	double v=0;
	int nt = wnt;
	if (m_SignedWord && (wnt & 0x8000))
		nt = (short)wnt;

	for (int i=m_Poly.size()-1;i>0;i--) 
		v = nt *( m_Poly[i] + v); 

	v += m_Poly[0];
	/*
	switch(m_Scale)
	{
	case 1:
		v = pow(10,v); break;
	case 2:
		v = exp(v); break;
	case 3:
		v = (v>0)?log10(v):0;break;
	case 4:
		v = (v>0)?log(v):0;break;
	default:
		break;

	}*/
	if (v < m_vLower || v > m_vUpper)
		return false;
	c.value = v;
	c.externaltype = m_Type;
	c.externaldeviceid = (device & m_Devicemask);  
	return true; 
}

bool CDeviceMeasurementConvertor::GetExternalDeviceID(long idUniqueDevice,  long &idExternalDevice, long &type)
{
	if ((m_TypeMask1 & idUniqueDevice) != m_TypeMask2)
		return false;
	idExternalDevice= (idUniqueDevice & m_Devicemask); 
	type = m_Type;
	return true;

}
bool CDeviceMeasurementConvertor::GetUniqueDeviceID(unsigned long idExternalDevice, unsigned long type, long& idUniqueDevice)
{
	if  (type != m_Type)
		return false;
	unsigned short w = (idExternalDevice | (~m_Devicemask));
	idUniqueDevice = w;
	return true;
}
