
void str_replace(char* strNew, char *str, char *old, char *newstr) ;
 


char* strcat1(char* buf, const char* c);

