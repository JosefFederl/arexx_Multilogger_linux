#include <string.h>
#include "convert.h"

char* strcat1(char* buf, const char* c)
{
	if (c==NULL)
		return buf;
	while(*c)
		*buf++ = *c++;
	*buf = 0;
	return buf;
}  
 
void str_replace(char* strNew, char *str, char *old, char *newstr) 
{
  int i, count = 0;
  int newlen = strlen(newstr);
  int oldlen = strlen(old);
   
     
  i = 0;
  while (*str)
    if (strstr(str, old) == str)
      strcpy(&strNew[i], newstr),
      i += newlen,
      str += oldlen;
    else
      strNew[i++] = *str++;
    
  strNew[i] = '\0';
 
}




